# pyrefly: ignore [missing-import]
import pcbnew
import subprocess
import os
import wx

class ExporterPlugin(pcbnew.ActionPlugin):
    def defaults(self):
        self.name = "KiForge"
        self.category = "Manufacturing"
        self.description = "Export BOM, STEP, 3D renders, SVGs, PDF and placement files."
        self.show_toolbar_button = True
        self.icon_file_name = os.path.join(os.path.dirname(__file__), "icon.png")

    def Run(self):
        # Get the active board layout
        board = pcbnew.GetBoard()
        if not board:
            wx.MessageBox("No board loaded. Please open a PCB layout file first.", "Error", wx.OK | wx.ICON_ERROR)
            return

        board_file = board.GetFileName()
        if not board_file or not board_file.endswith(".kicad_pcb"):
            wx.MessageBox("Please save/open the PCB file first to resolve its path.", "Error", wx.OK | wx.ICON_ERROR)
            return

        # Attempt to find the KiCad project file (.kicad_pro)
        pro_file = board_file.replace(".kicad_pcb", ".kicad_pro")
        if not os.path.isfile(pro_file):
            # Fallback: search for any .kicad_pro in the same directory
            project_dir = os.path.dirname(board_file)
            pro_files = [f for f in os.listdir(project_dir) if f.endswith(".kicad_pro")]
            if pro_files:
                pro_file = os.path.join(project_dir, pro_files[0])
            else:
                wx.MessageBox("Could not locate a KiCad project file (.kicad_pro) in the directory.", "Error", wx.OK | wx.ICON_ERROR)
                return
        else:
            project_dir = os.path.dirname(pro_file)

        project_name = os.path.splitext(os.path.basename(pro_file))[0]
        
        # Attempt to find the schematic file (.kicad_sch)
        sch_file = os.path.join(project_dir, f"{project_name}.kicad_sch")
        if not os.path.isfile(sch_file):
            sch_files = [f for f in os.listdir(project_dir) if f.endswith(".kicad_sch")]
            if sch_files:
                sch_file = os.path.join(project_dir, sch_files[0])
            else:
                sch_file = None

        # Build output directory in the same folder as the project
        output_dir = os.path.join(project_dir, "kiforge")
        os.makedirs(output_dir, exist_ok=True)

        commands = []
        friendly_names = []

        # 1. 3D Front Render
        commands.append([
            "kicad-cli", "pcb", "render", board_file,
            "--output", os.path.join(output_dir, f"{project_name}_3d_front.png"),
            "--rotate", "0,0,0", "--preset", "2", "--floor", "--perspective",
            "--zoom", "0.8", "--quality", "high", "--width", "1920", "--height", "1080"
        ])
        friendly_names.append("3D Render (Front)")

        # 2. 3D Back Render
        commands.append([
            "kicad-cli", "pcb", "render", board_file,
            "--output", os.path.join(output_dir, f"{project_name}_3d_back.png"),
            "--rotate", "0,180,0", "--preset", "2", "--floor", "--perspective",
            "--zoom", "0.8", "--quality", "high", "--width", "1920", "--height", "1080"
        ])
        friendly_names.append("3D Render (Back)")

        # 3. Front Copper SVG
        commands.append([
            "kicad-cli", "pcb", "export", "svg",
            "-l", "F.Cu,Edge.Cuts", "-n", "--drill-shape-opt", "2",
            "--cl", "Edge.Cuts", "--exclude-drawing-sheet",
            "--output", os.path.join(output_dir, f"{project_name}_front.svg"),
            "--black-and-white", board_file
        ])
        friendly_names.append("Front Copper SVG")

        # 4. Back Copper SVG
        commands.append([
            "kicad-cli", "pcb", "export", "svg",
            "-l", "B.Cu,Edge.Cuts", "-m", "-n", "--drill-shape-opt", "2",
            "--cl", "Edge.Cuts", "--exclude-drawing-sheet",
            "--output", os.path.join(output_dir, f"{project_name}_back.svg"),
            "--black-and-white", board_file
        ])
        friendly_names.append("Back Copper SVG")

        # 5. Bill of Materials (if schematic exists)
        if sch_file:
            commands.append([
                "kicad-cli", "sch", "export", "bom",
                "--fields", "Reference,Value,Footprint,Description,${QUANTITY},${DNP},ID",
                "--group-by", "Value,ID,Footprint,DNP", "--ref-range-delimiter", "",
                sch_file, "-o", os.path.join(output_dir, f"{project_name}_bom.csv")
            ])
            friendly_names.append("Bill of Materials CSV")

            # 6. Schematic PDF
            commands.append([
                "kicad-cli", "sch", "export", "pdf", sch_file,
                "-o", os.path.join(output_dir, f"{project_name}_sch.pdf")
            ])
            friendly_names.append("Schematic PDF")

        # 7. Position Placement File
        commands.append([
            "kicad-cli", "pcb", "export", "pos",
            "--format", "csv", "--exclude-dnp", "--use-drill-file-origin",
            "--units", "mm", board_file,
            "-o", os.path.join(output_dir, f"{project_name}_pos.csv")
        ])
        friendly_names.append("Placement Position CSV")

        # 8. STEP 3D Model
        commands.append([
            "kicad-cli", "pcb", "export", "step",
            "--no-optimize-step", "--subst-models", "-f",
            "-o", os.path.join(output_dir, f"{project_name}.step"), board_file
        ])
        friendly_names.append("STEP 3D Model")

        # Sequentially run the CLI commands, showing a wxProgressDialog
        progress = wx.ProgressDialog("KiForge", "Starting exports...", len(commands),
                                     style=wx.PD_AUTO_HIDE | wx.PD_APP_MODAL | wx.PD_CAN_ABORT)

        for i, cmd in enumerate(commands):
            keep_going, _ = progress.Update(i, f"Running: {friendly_names[i]}...")
            if not keep_going:
                wx.MessageBox("Export aborted by user.", "KiForge", wx.OK | wx.ICON_WARNING)
                progress.Destroy()
                return

            try:
                # Execute kicad-cli command
                subprocess.run(cmd, check=True, capture_output=True, text=True)
            except subprocess.CalledProcessError as e:
                wx.MessageBox(f"Command failed:\n{' '.join(cmd)}\n\nError output:\n{e.stderr or e.stdout}", 
                              "KiForge Error", wx.OK | wx.ICON_ERROR)
                progress.Destroy()
                return

        progress.Update(len(commands), "All exports completed successfully!")
        progress.Destroy()
        
        wx.MessageBox(f"All exports saved successfully in:\n{output_dir}", "KiForge Success", wx.OK | wx.ICON_INFORMATION)

# Register the ActionPlugin inside KiCad
ExporterPlugin().register()
